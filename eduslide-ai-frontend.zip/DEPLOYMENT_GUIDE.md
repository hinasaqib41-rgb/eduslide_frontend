# 🚀 DEPLOYMENT GUIDE - EduSlide AI Frontend

## 📁 Files to Upload to GitHub

Your React project has **15 files** organized in this structure:

```
eduslide-ai-frontend/
├── .env.example          # Environment variables template
├── .gitignore           # Git ignore file
├── README.md            # Project documentation
├── package.json         # Dependencies
├── vite.config.js       # Vite configuration
├── index.html           # HTML entry point
└── src/
    ├── main.jsx         # React entry point
    ├── App.jsx          # Main app component
    ├── App.css          # App styles
    ├── index.css        # Global styles
    ├── api.js           # API configuration
    └── components/
        ├── TopicGenerator.jsx      # Topic input component
        ├── PdfGenerator.jsx        # PDF upload component
        ├── ImageGenerator.jsx      # Image upload component
        └── Generator.css           # Shared component styles
```

## 📤 Step-by-Step: Upload to GitHub

### Option 1: Using GitHub Web Interface

1. **Create a new repository on GitHub**
   - Go to https://github.com/new
   - Name: `eduslide-ai-frontend`
   - Keep it public or private
   - DON'T initialize with README (you already have one)
   - Click "Create repository"

2. **Upload files via GitHub web**
   - Click "uploading an existing file"
   - Drag and drop ALL 15 files (maintaining folder structure)
   - Commit the files

### Option 2: Using Git Command Line (Recommended)

```bash
# 1. Navigate to your project folder (where all files are)
cd /path/to/your/eduslide-ai-frontend

# 2. Initialize git repository
git init

# 3. Add all files
git add .

# 4. Commit files
git commit -m "Initial commit: EduSlide AI frontend"

# 5. Add your GitHub repository as remote
git remote add origin https://github.com/YOUR-USERNAME/eduslide-ai-frontend.git

# 6. Push to GitHub
git branch -M main
git push -u origin main
```

## 🌐 Deploy to Vercel

### Method 1: Vercel Dashboard (Easiest)

1. **Go to Vercel**
   - Visit https://vercel.com
   - Sign up/Login with GitHub

2. **Import Project**
   - Click "Add New" → "Project"
   - Select your GitHub repository `eduslide-ai-frontend`
   - Click "Import"

3. **Configure Project**
   - Framework Preset: **Vite** (auto-detected)
   - Build Command: `npm run build` (auto-filled)
   - Output Directory: `dist` (auto-filled)
   - Install Command: `npm install` (auto-filled)

4. **Add Environment Variable**
   - Click "Environment Variables"
   - Add:
     - Name: `VITE_API_URL`
     - Value: `https://YOUR-HUGGINGFACE-USERNAME-eduslide-ai.hf.space`
   - Apply to: Production, Preview, and Development

5. **Deploy**
   - Click "Deploy"
   - Wait 2-3 minutes
   - Your app will be live at: `https://your-project.vercel.app`

### Method 2: Vercel CLI

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login to Vercel
vercel login

# 3. Deploy (from project directory)
vercel

# 4. Set environment variable
vercel env add VITE_API_URL production
# Enter: https://YOUR-HUGGINGFACE-URL.hf.space

# 5. Deploy to production
vercel --prod
```

## 🔧 Important Configuration

### Backend URL Setup

**Your HuggingFace Docker backend URL format:**
```
https://YOUR-USERNAME-eduslide-ai.hf.space
```

**Set this in Vercel:**
- Variable Name: `VITE_API_URL`
- Variable Value: Your HuggingFace Space URL

### CORS Configuration (Backend)

Make sure your backend (HuggingFace Docker) allows CORS from your Vercel domain:

```python
# In your app.py (backend)
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=[
    "https://your-project.vercel.app",
    "http://localhost:3000"  # for local development
])
```

## ✅ Testing Your Deployment

1. **Visit your Vercel URL**
2. **Test each tab:**
   - Topic Generator: Enter "Python Programming" → Generate
   - PDF Generator: Upload a PDF → Generate
   - Image Generator: Upload an image → Generate

3. **Check for common issues:**
   - ❌ CORS errors → Fix backend CORS settings
   - ❌ API timeout → Normal (slides take 30-120 seconds)
   - ❌ 404 errors → Check VITE_API_URL is correct

## 🔄 Continuous Deployment

Once connected to GitHub, Vercel auto-deploys when you push changes:

```bash
# Make changes to your code
git add .
git commit -m "Update: improved UI"
git push origin main

# Vercel automatically rebuilds and deploys!
```

## 📊 Project Structure Summary

**Total Files: 15**
- Root files: 6
- Source files: 5
- Component files: 4

**Total Folders: 2**
- `src/`
- `src/components/`

## 🎯 Quick Checklist

- [ ] All 15 files uploaded to GitHub
- [ ] Repository is public/accessible
- [ ] Connected GitHub to Vercel
- [ ] Added VITE_API_URL environment variable
- [ ] Backend URL is correct (HuggingFace Space)
- [ ] CORS configured on backend
- [ ] Tested all three generators
- [ ] Slides download successfully

## 🆘 Troubleshooting

**Problem: "Module not found" errors**
- Solution: Make sure folder structure is preserved (src/components/)

**Problem: Blank page on Vercel**
- Solution: Check browser console for errors
- Check VITE_API_URL is set correctly

**Problem: CORS errors**
- Solution: Update backend CORS to include your Vercel domain

**Problem: Long loading times**
- Expected: Slide generation takes 30-120 seconds
- Not an error if loading spinner shows

## 📝 Next Steps After Deployment

1. Share your app URL with users
2. Add custom domain in Vercel (optional)
3. Monitor usage in Vercel Analytics
4. Add more features to frontend
5. Consider adding authentication

## 🎉 You're Done!

Your EduSlide AI frontend is now live and connected to your HuggingFace backend!

**Frontend:** https://your-project.vercel.app
**Backend:** https://your-username-eduslide-ai.hf.space

Happy deploying! 🚀
